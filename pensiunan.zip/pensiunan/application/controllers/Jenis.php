<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jenis extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_jenis');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Jenis';

        $data['jenis'] = $this->Model_jenis->getAllJenis();
        if( $this->input->post('keyword') ) {
            $data['jenis'] = $this->Model_jenis->Carijenis();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('jenis/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('jenis', 'Jenis', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Jenis';

            $this->load->view('templates/header.php', $data);
            $this->load->view('jenis/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_jenis->Tambahjenis();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('jenis');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('jenis', 'Jenis', 'trim|required');
        $data['jenis'] = $this->Model_jenis->getJenisById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Jenis';

            $this->load->view('templates/header.php', $data);
            $this->load->view('jenis/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_jenis->Ubahjenis();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('jenis');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_jenis->hapusJenis($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('jenis');
    }
}
