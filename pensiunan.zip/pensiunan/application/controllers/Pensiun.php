<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pensiun extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_pensiun');
        $this->load->model('Model_jenis');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Pensiun';
        if ($this->input->post('submit')) {
            $data['keyword'] = $this->input->post('keyword');
        } else {
            $data['keyword'] = null;
        }
        
        $data['pensiun'] = $this->Model_pensiun->getAllPensiun($data['keyword']);
       
        $this->load->view('templates/header.php', $data);
        $this->load->view('pensiun/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    
    public function tambah()
    {
        $data['jenis'] = $this->Model_jenis->getAllJenis();
        $this->form_validation->set_rules('nopen', 'Nopen', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('no_rekening', 'No_rekening', 'trim|required|numeric');
        $this->form_validation->set_rules('jenis', 'Jenis', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('tanggal_pensiun', 'Tanggal_pensiun', 'trim|required');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Pensiun';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pensiun/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_pensiun->Tambahpensiun();
            redirect('pensiun');
        }
        
    }

    public function ubah($id)
    {
        $data['pensiun'] = $this->Model_pensiun->getPensiunById($id);
        $data['jenis'] = $this->Model_jenis->getAllJenis();
        $this->form_validation->set_rules('nopen', 'Nopen', 'trim|required|numeric');
        $this->form_validation->set_rules('nama', 'Nama', 'trim|required');
        $this->form_validation->set_rules('no_rekening', 'No_rekening', 'trim|required|numeric');
        $this->form_validation->set_rules('jenis', 'Jenis', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('tanggal_pensiun', 'Tanggal_pensiun', 'trim|required');
        $this->form_validation->set_rules('hp', 'Hp', 'trim|required|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'trim|required');


        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Pensiun';

            $this->load->view('templates/header.php', $data);
            $this->load->view('pensiun/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_pensiun->Ubahpensiun();
            $old_image = $data['pensiun']['foto'];
            unlink(FCPATH . 'assets/foto/' . $old_image);
            $this->session->set_flashdata('flash', 'Diubahkan');
            redirect('pensiun');
        }
        
    }

    public function detail($id)
    {
        $data['pensiun'] = $this->Model_pensiun->getPensiunById($id);
       
        $data['title'] = 'Detail Pensiun';
        $this->load->view('templates/header.php', $data);
        $this->load->view('pensiun/detail.php', $data);
        $this->load->view('templates/footer.php');

    }

    public function hapus($id)
    {
        $data['pensiun'] = $this->Model_pensiun->getPensiunById($id);
        $old_image = $data['pensiun']['foto'];
        unlink(FCPATH . 'assets/foto/' . $old_image);
        $this->Model_pensiun->hapusPensiun($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('pensiun');
    }
}