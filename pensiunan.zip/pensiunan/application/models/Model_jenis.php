<?php
class Model_jenis extends CI_Model 
{
    public function getAllJenis()
    {
        return $query = $this->db->get('jenis')->result_array();
    }

    public function Tambahjenis()
    {
        $data = [
            "jenis" => $this->input->post('jenis', true)
        ];

        $this->db->insert('jenis', $data);
    }

    public function Ubahjenis()
    {
        $data = [
            "jenis" => $this->input->post('jenis', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('jenis', $data);
    }

    public function hapusJenis($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('jenis');
    }

    public function getJenisById($id)
    {
        return $this->db->get_where('jenis', ['id' => $id])->row_array();
    }

    public function Carijenis()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('jenis', $keyword);
        return $this->db->get('jenis')->result_array();
    }
}

?>