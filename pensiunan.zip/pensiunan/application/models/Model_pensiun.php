<?php
class Model_pensiun extends CI_Model 
{

    public function getAllPensiun($keyword = null)
    {
        if( $keyword ) {
            $this->db->like('nopen', $keyword);
            $this->db->or_like('nama', $keyword);
            $this->db->or_like('no_rekening', $keyword);
            $this->db->or_like('jenis', $keyword);
            $this->db->or_like('email', $keyword);
            $this->db->or_like('tanggal_pensiun', $keyword);
            $this->db->or_like('hp', $keyword);
            $this->db->or_like('alamat', $keyword);
        }
        //create view sql siswa dengan join yang ada pada edit
        return $query = $this->db->get('joinpensiun')->result_array();
    }

    public function Tambahpensiun()
    {
        $upload_image = $_FILES['image']['name'];
            if($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/foto/';

            $this->load->library('upload', $config);

            if($this->upload->do_upload('image')) {
                $foto = $this->upload->data('file_name');
                $data = [
                    "nopen" => $this->input->post('nopen', true),
                    "foto" => $foto,
                    "nama" => $this->input->post('nama', true),
                    "no_rekening" => $this->input->post('no_rekening', true),
                    "id_jenis" => $this->input->post('jenis', true),
                    "email" => $this->input->post('email', true),
                    "tanggal_pensiun" => $this->input->post('tanggal_pensiun', true),
                    "hp" => $this->input->post('hp', true),
                    "alamat" => $this->input->post('alamat', true)
                ];
                
                $this->db->insert('pensiun', $data);
                
                $this->session->set_flashdata('flash', 'Ditambahkan');

            } else {
                $this->session->set_flashdata('error', $this->upload->display_errors());
            }
        }
    }

    public function Ubahpensiun()
    {
        $upload_image = $_FILES['image']['name'];
            if($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/foto/';

            $this->load->library('upload', $config);

            if($this->upload->do_upload('image')) {
                $foto = $this->upload->data('file_name');
                $this->db->set('foto', $foto);
            } else {
                $this->session->set_flashdata('error', $this->upload->display_errors());
            }
        }

        $id = $this->input->post('id', true);
        $nopen = $this->input->post('nopen', true);
        $nama = $this->input->post('nama', true);
        $no_rekening = $this->input->post('no_rekening', true);
        $id_jenis = $this->input->post('jenis', true);
        $email = $this->input->post('email', true);
        $tanggal_pensiun = $this->input->post('tanggal_pensiun', true);
        $hp = $this->input->post('hp', true);
        $alamat = $this->input->post('alamat', true);

        $this->db->set('nopen', $nopen);
        $this->db->set('nama', $nama);
        $this->db->set('no_rekening', $no_rekening);
        $this->db->set('id_jenis', $id_jenis);
        $this->db->set('email', $email);
        $this->db->set('tanggal_pensiun', $tanggal_pensiun);
        $this->db->set('hp', $hp);
        $this->db->set('alamat', $alamat);

        $this->db->where('id', $id);
        $this->db->update('pensiun');
    }

    public function hapusPensiun($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('pensiun');
    }

    public function getPensiunById($id)
    {
        $joinpensiun = "SELECT    a.id,
                                a.nopen,
                                a.foto,
                                a.nama,
                                a.no_rekening,
                                a.id_jenis,
                                b.jenis,
                                a.email,
                                a.tanggal_pensiun,
                                a.hp,
                                a.alamat
                                FROM pensiun AS a
                                JOIN jenis AS b
                                ON a.id_jenis = b.id
                                WHERE a.id = $id";
        return $query = $this->db->query($joinpensiun)->row_array();
    }

    public function Caripensiun()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nopen', $keyword);
        $this->db->or_like('nama', $keyword);
        $this->db->or_like('no_rekening', $keyword);
        $this->db->or_like('jenis', $keyword);
        $this->db->or_like('email', $keyword);
        $this->db->or_like('tanggal_pensiun', $keyword);
        $this->db->or_like('hp', $keyword);
        $this->db->or_like('alamat', $keyword);
        return $this->db->get('jenis')->result_array();
    }
}