<!DOCTYPE html>
<html>

<head>
    <!-- Site made with Mobirise Website Builder v5.6.4, https://mobirise.com -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="generator" content="Mobirise v5.6.4, mobirise.com">
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:image:src" content="">
    <meta property="og:image" content="">
    <meta name="twitter:title" content="LearnM5 Online Spanish Courses Demo">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <link rel="shortcut icon" href="assets/images/logo.jpg" type="image/x-icon">
    <meta name="description" content="New LearnM5 Theme HTML Template - Download Now!">


    <title>pensiunan</title>
    <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="assets/dropdown/css/style.css">
    <link rel="stylesheet" href="assets/socicon/css/styles.css">
    <link rel="stylesheet" href="assets/theme/css/style.css">
    <link rel="stylesheet" href="assets/recaptcha.css">
    <link rel="preload"
        href="https://fonts.googleapis.com/css?family=Plus+Jakarta+Sans:200,300,400,500,600,700,800,200i,300i,400i,500i,600i,700i,800i&display=swap"
        as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet"
            href="https://fonts.googleapis.com/css?family=Plus+Jakarta+Sans:200,300,400,500,600,700,800,200i,300i,400i,500i,600i,700i,800i&display=swap">
    </noscript>
    <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css">
    <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">




</head>

<body>

    <section data-bs-version="5.1" class="menu menu1 cid-t6VeqPfvu7" once="menu" id="menu01-0">


        <nav class="navbar navbar-dropdown navbar-expand-lg">
            <div class="container">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse"
                    data-target="#navbarSupportedContent" data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <div class="hamburger">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </button>
            </div>
        </nav>
    </section>

    <section data-bs-version="5.1" class="header1 cid-t6VeqVp4Tv" id="header01-1">






        <div class="container">
            <div class="wrapper">
                <div class="row justify-content-center">


                    <div class="col-12 col-md-12 m-auto col-lg-6">
                        <div class="text-wrapper align-left">
                            <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1"><strong>PT.POS INDONESIA</strong></h1>
                            <p class="mbr-text align-left mbr-fonts-style display-7">
                            Pos Indonesia merupakan sebuah badan usaha milik negara
(BUMN) Indonesia yang bergerak di bidang layanan pos. Saat ini, bentuk
badan usaha Pos Indonesia merupakan perseroan terbatas yang sering
disebut dengan PT. Pos Indonesia. Bentuk usaha Pos Indonesia ini
berdasarkan Peraturan Pemerintah Republik Indonesia Nomor 5 tahun
1995. Peraturan Pemerintah tersebut berisi tentang pengalihan bentuk
awal Pos Indonesia yang berupa perusahaan umum (perum) menjadi
sebuah perusahaan (persero).
 <br><br>Kantor pos pertama didirikan di Batavia (sekarang Jakarta) oleh
Gubernur Jendral G.W Baron van Imhoff pada tanggal 26 Agustus 1746
dengan tujuan untuk lebih menjamin keamanan surat-surat penduduk,
terutama bagi mereka yang berdagang dari kantor-kantor di luar Jawa dan
bagi mereka yang datang dari dan pergi ke Negeri Belanda. Sejak itulah
pelayanan pos telah lahir mengemban peran dan fungsi pelayanan
kepada publik.<br></p>
                            
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-6 image-wrapper">
                        <img class="w-100" src="assets/foto/logo.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>