<div class="container">
    <div class="card" style="width: 18rem;">
    <img src="<?= base_url('assets/foto/') . $pensiun['foto']; ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?= $pensiun['nopen']; ?></h5>
            <p class="card-text"><?= $pensiun['nama']; ?></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?= $pensiun['no_rekening']; ?></li>
            <li class="list-group-item"><?= $pensiun['jenis']; ?></li>
            <li class="list-group-item"><?= $pensiun['email']; ?></li>
            <li class="list-group-item"><?= $pensiun['tanggal_pensiun']; ?></li>
            <li class="list-group-item"><?= $pensiun['hp']; ?></li>
            <li class="list-group-item"><?= $pensiun['alamat']; ?></li>
        </ul>
        <div class="card-body">
            <a href="<?= base_url('pensiun'); ?>" class="btn btn-primary">Kembali</a>
        </div>
    </div>
</div>

