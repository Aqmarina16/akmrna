<div class="container">
    <?= form_open_multipart();?>
        <legend>Ubah Data pensiun</legend>
        <input type="hidden" name="id" value="<?= $pensiun['id']; ?>">
        <div class="mb-3">
            <label for="nopen" class="form-label">Nopen</label>
            <input type="text" class="form-control" id="nopen" name="nopen" value="<?= $pensiun['nopen']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nopen'); ?></div>
        </div>
        <div class="row">
            <div class="col">
              <label for="formFile" class="form-label">Foto</label>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="mb-3">
                    <img src="<?= base_url('assets/foto/') . $pensiun['foto']; ?>"  id="formFile" class="img-thumbnail" width="225" height="330">
                    <input class="form-control" type="file" id="formFile" name="image" value="<?= $pensiun['foto']; ?>" style="width : 500px;" require>
                    <div class="form-text text-danger"><?= form_error('image'); ?></div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $pensiun['nama']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="no_rekening" class="form-label">No rekening</label>
            <input type="text" class="form-control" id="no_rekening" name="no_rekening" value="<?= $pensiun['no_rekening']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('no_rekening'); ?></div>
        </div>
        <div class="mb-3">
            <label for="jenis" class="form-label">Jenis Pensiunan</label>
            <select class="form-select" id="jenis" name="jenis" style="width : 500px;">
                <option selected value="<?= $pensiun['id_jenis']; ?>"><?= $pensiun['jenis']; ?></option>
            <?php foreach( $jenis as $jen ) : ?>
                <option value="<?= $jen['id']; ?>"><?= $jen['jenis']; ?></option>
            <?php endforeach; ?>
            </select>
            <div class="form-text text-danger"><?= form_error('jenis'); ?></div>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= $pensiun['email']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('email'); ?></div>
        </div>
        <div class="mb-3">
            <label for="tanggal_pensiun" class="form-label">tanggal pensiun</label>
            <input type="tanggal_pensiun" class="form-control" id="email" name="tanggal_pensiun" value="<?= $pensiun['tanggal_pensiun']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('tanggal_pensiun'); ?></div>
        </div>
        <div class="mb-3">
            <label for="hp" class="form-label">Hp</label>
            <input type="text" class="form-control" id="hp" name="hp" value="<?= $pensiun['hp']; ?>" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('hp'); ?></div>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <textarea class="form-control" id="alamat" name="alamat" style="width : 500px;"><?= $pensiun['alamat']; ?></textarea>
            <div class="form-text text-danger"><?= form_error('alamat'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>

