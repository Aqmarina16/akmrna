<div class="container">
    <form action="" method="post">
        <legend>Ubah Data jenis pensiunan</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $jenis['id']; ?>">
            <label for="jenis" class="form-label">Nama Jenis Pensiunan</label>
            <input type="text" class="form-control" id="jenis" name="jenis" value="<?= $jenis['jenis']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('jenis'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>