<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Jenis pensiun</legend>
        <div class="mb-3">
            <label for="jenis" class="form-label">Nama Jenis Pensiunan</label>
            <input type="text" class="form-control" id="jenis" name="jenis" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('jenis'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>