-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2023 at 05:38 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penggajian`
--

-- --------------------------------------------------------

--
-- Table structure for table `jenis`
--

CREATE TABLE `jenis` (
  `id` int(11) NOT NULL,
  `jenis` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jenis`
--

INSERT INTO `jenis` (`id`, `jenis`) VALUES
(1, 'TNI AU'),
(2, 'TNI AD');

-- --------------------------------------------------------

--
-- Stand-in structure for view `joinpensiun`
-- (See below for the actual view)
--
CREATE TABLE `joinpensiun` (
`id` int(11)
,`nopen` text
,`foto` varchar(100)
,`nama` varchar(100)
,`no_rekening` int(20)
,`id_jenis` int(11)
,`jenis` varchar(50)
,`email` varchar(50)
,`tanggal_pensiun` date
,`hp` int(15)
,`alamat` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `pensiun`
--

CREATE TABLE `pensiun` (
  `id` int(11) NOT NULL,
  `nopen` text NOT NULL,
  `foto` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `no_rekening` int(20) NOT NULL,
  `id_jenis` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tanggal_pensiun` date NOT NULL,
  `hp` int(15) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pensiun`
--

INSERT INTO `pensiun` (`id`, `nopen`, `foto`, `nama`, `no_rekening`, `id_jenis`, `email`, `tanggal_pensiun`, `hp`, `alamat`) VALUES
(5, '23456', 'Snapshot_20230107082650627_(1)2.png', 'AKU', 12345, 1, 'AKU@gmail.com', '2023-03-16', 2467, 'jlnkfh');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Structure for view `joinpensiun`
--
DROP TABLE IF EXISTS `joinpensiun`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `joinpensiun`  AS SELECT `a`.`id` AS `id`, `a`.`nopen` AS `nopen`, `a`.`foto` AS `foto`, `a`.`nama` AS `nama`, `a`.`no_rekening` AS `no_rekening`, `a`.`id_jenis` AS `id_jenis`, `b`.`jenis` AS `jenis`, `a`.`email` AS `email`, `a`.`tanggal_pensiun` AS `tanggal_pensiun`, `a`.`hp` AS `hp`, `a`.`alamat` AS `alamat` FROM (`pensiun` `a` join `jenis` `b` on(`a`.`id_jenis` = `b`.`id`))  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jenis`
--
ALTER TABLE `jenis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pensiun`
--
ALTER TABLE `pensiun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jenis`
--
ALTER TABLE `jenis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pensiun`
--
ALTER TABLE `pensiun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
